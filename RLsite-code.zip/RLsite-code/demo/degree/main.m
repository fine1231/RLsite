data=load('Inputs/1uud_contact.dat');
A=degrees(data);
dlmwrite('Outputs/1uud_degree.txt',A);